#ifndef MATHLIBRARY_H
#define MATHLIBRARY_H

#include <string>
#include <vector>

class MathLibrary {
public:
    static std::vector<std::string> BuscarRecetas(const std::string& ingredientes);
};

#endif
