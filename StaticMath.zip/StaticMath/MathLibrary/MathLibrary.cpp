#include "MathLibrary.h"

std::vector<std::string> MathLibrary::BuscarRecetas(const std::string& ingredientes) {
    std::vector<std::string> recetasEncontradas;

    if (ingredientes.find("pasta") != std::string::npos || ingredientes.find("queso") != std::string::npos) {
        recetasEncontradas.push_back("Spaghetti a la carbonara");
    }
    if (ingredientes.find("patatas") != std::string::npos || ingredientes.find("huevos") != std::string::npos) {
        recetasEncontradas.push_back("Tortilla de patatas");
    }
    if (ingredientes.find("chocolate") != std::string::npos || ingredientes.find("harina") != std::string::npos) {
        recetasEncontradas.push_back("Tarta de chocolate");
    }

    return recetasEncontradas;
}
