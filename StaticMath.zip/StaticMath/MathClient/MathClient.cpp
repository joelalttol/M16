#include <iostream>
#include <vector>
#include "MathLibrary.h" 

int main() {
    std::cout << "Ingrese los ingredientes (pasta, queso, patatas, huevos, chocolate o harina ): ";
    std::string ingredientes;
    std::getline(std::cin, ingredientes);

    std::vector<std::string> recetas = MathLibrary::BuscarRecetas(ingredientes);

    if (recetas.empty()) {
        std::cout << "No se encontraron recetas para los ingredientes proporcionados." << std::endl;
    }
    else {
        std::cout << "Recetas encontradas:" << std::endl;
        for (const auto& receta : recetas) {
            std::cout << "- " << receta << std::endl;
        }
    }

    return 0;
}
